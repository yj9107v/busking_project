package busking.busking_project.Busking_Schedule;

public enum BuskingStatus {
    SCHEDULED, // 예정
    ONGOING,   // 진행 중
    COMPLETED  // 완료
}
