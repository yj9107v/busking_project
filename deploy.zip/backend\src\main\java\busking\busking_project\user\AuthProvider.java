package busking.busking_project.user;

public enum AuthProvider {
    LOCAL, GOOGLE, KAKAO
}

