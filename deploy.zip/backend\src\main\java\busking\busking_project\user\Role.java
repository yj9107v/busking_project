package busking.busking_project.user;

public enum Role {
    USER
}

